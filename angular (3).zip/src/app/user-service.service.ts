import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Userdriving } from './DTO/userdriving';
import { Companies } from './DTO/companies';
import { Observable } from 'rxjs';
import { Userpost } from './userpost';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  userId !: number;

  public retrieveCompaniesURL = 'http://localhost:8080/api/applications/companies';
  private registerUsersURL='http://localhost:8080/api/applications/new';
  private getPendingURL='http://localhost:8080/api/applications/';
  private VerifyUserURL='http://localhost:8080/api/applications';
  private retrieveByUserIdURL='http://localhost:8080/api/applications';
  //private deleteEmployeeByIdURL='http://localhost:8083/api/employees';

  constructor(private http:HttpClient) { }

  public registerUsers(userpost:Userpost) {
    console.log(userpost);
    return this.http.post<String>(this.registerUsersURL, userpost);
  }

  //public getCompanies() {
  //  return this.http.get<Companies[]>(this.retrieveCompaniesURL);
  //}

  getCompanies(){
    return this.http.get<Companies[]>('http://localhost:8080/api/applications/companies');
  }

  public getPending() {
    return this.http.get<Userdriving[]>(this.getPendingURL);
  }

  public getuserbyid(userdriving: Userdriving){
     this.userId=userdriving.userId ;
    console.log(this.retrieveByUserIdURL+'/'+userdriving.userId)
    return this.http.get<Userdriving>('http://localhost:8080/api/applications/'+userdriving.userId);


  }

  public verifyuser(mrd : Userdriving){
    return this.http.put<Userdriving>(this.VerifyUserURL+"/"+mrd.userId,mrd);
  }

  public getuserid(){
    return this.userId;
  }




}
