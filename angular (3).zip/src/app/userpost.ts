export class Userpost {

    userId !:number;
    userNme !:string;
    officialEmail !:string;
    phoneNumber !:string;
    designation !:string;
    role !:string;
    employeeId !:string;
    aadharNumber !:string;
    applicationStatus !:string;
    Id !:number;
    licenseNo !:string;
    expirationDate !:Date;
    rta !:string;
    allowedVehicles !:string;
    companyId !:number;
}
