import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './navigation/navigation.component';
import { NewApplicationComponent } from './new-application/new-application.component';
import { ApplicationRequestListComponent } from './application-request-list/application-request-list.component';
import { CompaniesListComponent } from './companies-list/companies-list.component';
import { ViewbyIDComponent } from './viewby-id/viewby-id.component';
import { ApplicationRequestComponent } from './application-request/application-request.component';
import { RouterModule } from '@angular/router';
import { AdditionalfieldsComponent } from './additionalfields/additionalfields.component';
import { HttpClientModule } from '@angular/common/http';
import { UserServiceService } from './user-service.service';
@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    NewApplicationComponent,
    ApplicationRequestListComponent,
    CompaniesListComponent,
    ViewbyIDComponent,
    ApplicationRequestComponent,
    AdditionalfieldsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [UserServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
