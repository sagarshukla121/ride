import { Component, OnInit } from '@angular/core';
import { Userdriving } from '../DTO/userdriving';
import { Userpost } from '../userpost';
import { FormControl,FormGroup,Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-new-application',
  templateUrl: './new-application.component.html',
  styleUrls: ['./new-application.component.css']
})
export class NewApplicationComponent implements OnInit {

  Role: string='';
  formData:any;
  //userdriving: Userdriving=new Userdriving();
  userpost: Userpost=new Userpost();
  submitted = false;

  constructor(private userservice: UserServiceService) { }

  ngOnInit(): void {
    this.formData=new FormGroup(
      {
        userNme: new FormControl("",Validators.compose(
          [
            Validators.required,
            
          ]
        )),
        officialEmail: new FormControl("",Validators.compose(
   [
     Validators.required,
     
   ]
 )),

 phoneNumber: new FormControl("",Validators.compose(
   [
     Validators.required,
     Validators.pattern('^9\\d{9}$')
   ]
 )),

 designation: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
)),

employeeId: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
)),

aadharNumber: new FormControl("",Validators.compose(
  [
    Validators.required,
    Validators.pattern('\\d{12}$')
  ]
)),

role: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
)),

applicationStatus: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
)),

licenseNo: new FormControl("",Validators.compose(
  [
    Validators.required,
    Validators.pattern('[a-zA-Z]{3}[0-9]{4}[a-zA-Z]{3}')
  ]
)),

expirationDate: new FormControl("",Validators.compose(
  [
    Validators.required,
    this.validateExpirationDate
    
  ]
)),

rta: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
)),

allowedVehicles: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
)),
companyId: new FormControl("",Validators.compose(
  [
    Validators.required,
    
  ]
))



      }
    )
  }

  validateExpirationDate(control: any): { [key: string]: boolean } | null {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();

    if (selectedDate < currentDate) {
      return { pastDate: true }; // Custom validation error key
    }

    return null; // Valid date
  }

  newIntern(): void {
    this.submitted = false;
    //this.userdriving = new Userdriving();
    this.userpost=new Userpost();
  }
  save() {
    console.log(this.userpost);
    this.userservice.registerUsers(this.userpost)
      .subscribe(data => console.log(data), error => console.log(error));
      // console.log(data);
      
    //this.userdriving = new Userdriving();
    this.userpost=new Userpost();
  }
  onsubmit(){

    this.submitted=true;
    this.save();
  }

}
