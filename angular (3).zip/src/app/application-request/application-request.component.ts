import { Component, OnInit } from '@angular/core';
import { Userdriving } from '../DTO/userdriving';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-application-request',
  templateUrl: './application-request.component.html',
  styleUrls: ['./application-request.component.css']
})
export class ApplicationRequestComponent implements OnInit {

      user: Userdriving=new Userdriving();
      submitted = false;
      users !: Userdriving[];

  constructor(private userservice:UserServiceService) { 
    this.user.userId=userservice.getuserid();
    this.userservice.getuserbyid(this.user)
    .subscribe( data => {
      this.user = data;
      console.log(data);
    
      // this.user.userId=data['userId'] ;
      // this.user.aadharNumber=data['aadharNumber'];
      // this.user.applicationstatus=data['applicationstatus': any];
      // this.user.employeeId=data['employeeId'];
      // this.user.company.id=data['id'];
      // this.user.designation=data['designation'];
      // this.user.officialEmail=data['officialEmail'];
      // this.user.role=data['role'];
      // this.user.phoneNumber=data['phoneNumber'];
      // this.user.username=data['username'];
        
    });
  }

  ngOnInit(): void {
  }

  verifyuser() :void{
    this.submitted=false;
    // this.user=new Userdriving();
  }

  update(){
    this.userservice.verifyuser(this.user)
    .subscribe(data => console.log(data), error => console.log(error));
    // this.user=new Userdriving();
  }

  onSubmit() {
    this.submitted = true;
    this.update();
  }

}
