import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Userdriving } from '../DTO/userdriving';
import { UserServiceService } from '../user-service.service';
@Component({
  selector: 'app-application-request-list',
  templateUrl: './application-request-list.component.html',
  styleUrls: ['./application-request-list.component.css']
})
export class ApplicationRequestListComponent implements OnInit {
users !:Userdriving[];
  constructor(private router: Router, private userservice:UserServiceService) {
    this.userservice.getPending()
    .subscribe(data=> {
      this.users=data;
      console.log(this.users);
      
      
    });
   }

  ngOnInit(): void {
  }

}
