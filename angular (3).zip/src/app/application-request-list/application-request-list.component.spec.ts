import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationRequestListComponent } from './application-request-list.component';

describe('ApplicationRequestListComponent', () => {
  let component: ApplicationRequestListComponent;
  let fixture: ComponentFixture<ApplicationRequestListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplicationRequestListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApplicationRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
