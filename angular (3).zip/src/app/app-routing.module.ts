import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewApplicationComponent } from './new-application/new-application.component';
import { ApplicationRequestListComponent } from './application-request-list/application-request-list.component';
import { CompaniesListComponent } from './companies-list/companies-list.component';
import { ViewbyIDComponent } from './viewby-id/viewby-id.component';
import { ApplicationRequestComponent } from './application-request/application-request.component';

export const routes: Routes = [
  {path:'new' , component:NewApplicationComponent},
  {path:'pending',component:ApplicationRequestListComponent},
  {path:'companies',component:CompaniesListComponent},
  {path:'applications/:userid' , component:ViewbyIDComponent},
  {path:'update' , component:ApplicationRequestComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})



export class AppRoutingModule { }
export const routingComponents=[
  NewApplicationComponent,
  ApplicationRequestListComponent,
  CompaniesListComponent,
  ViewbyIDComponent,
  ApplicationRequestComponent

]