import { Component, OnInit } from '@angular/core';
import { Userdriving } from '../DTO/userdriving';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { NgForm } from '@angular/forms';
import { FormControl,FormGroup, } from '@angular/forms';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-viewby-id',
  templateUrl: './viewby-id.component.html',
  styleUrls: ['./viewby-id.component.css']
})
export class ViewbyIDComponent implements OnInit {

  user: Userdriving=new Userdriving();
  users !: Userdriving[];
  submitted = false;
  noRecordFound=false;
  userId !: number;
  myGroup!:FormGroup;


  newteset: Userdriving=new Userdriving();

  constructor(private router: Router,private userservice:UserServiceService) { }

  //  search(){
  //    console.log(this.user)
  //    this.userservice.getuserbyid(this.user)
  //    .subscribe( data => {
  //      this.user = data;
  //      console.log(this.user);

  //      if(this.user.userId===0){
  //        console.log("in if");
  //        this.noRecordFound=true;
  //      }
  //    });
   
  //  }

  ngOnInit(): void {
    this.myGroup=new FormGroup({
      userId: new FormControl("",Validators.compose(
        [
          Validators.required,
          
        ]
      ))
    }
    //this.userId : new FormControl()      
    );
  }


  onSubmit() {
    // console.log(JSON.stringify(this.employee.empId));
     this.submitted = true;
     //this.search();
     console.log(this.myGroup)
     this.userservice.getuserbyid(this.myGroup.value)
     .subscribe( data => {
       this.user = data;
       console.log(this.user);

       if(this.user.userId===0){
         console.log("in if");
         this.noRecordFound=true;
       }
     });
    // this.sendEmployee();
 
    }

}
