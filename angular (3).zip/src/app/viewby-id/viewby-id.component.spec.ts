import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewbyIDComponent } from './viewby-id.component';

describe('ViewbyIDComponent', () => {
  let component: ViewbyIDComponent;
  let fixture: ComponentFixture<ViewbyIDComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewbyIDComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewbyIDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
