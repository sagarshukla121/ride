import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Companies } from '../DTO/companies';
import { UserServiceService } from '../user-service.service';
@Component({
  selector: 'app-companies-list',
  templateUrl: './companies-list.component.html',
  styleUrls: ['./companies-list.component.css']
})
export class CompaniesListComponent implements OnInit {
company !:Companies[];
  constructor(private router: Router, private userservice:UserServiceService) { 
    this.userservice.getCompanies()
    .subscribe(data => {
      this.company=data;
      console.log(this.company);
      // console.log(this.company);
      

    });
    
   
  }

  ngOnInit():void {
    
  }

}
