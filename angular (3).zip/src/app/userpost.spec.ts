import { Userpost } from './userpost';

describe('Userpost', () => {
  it('should create an instance', () => {
    expect(new Userpost()).toBeTruthy();
  });
});
