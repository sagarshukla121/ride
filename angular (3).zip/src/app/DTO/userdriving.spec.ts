import { Userdriving } from './userdriving';

describe('Userdriving', () => {
  it('should create an instance', () => {
    expect(new Userdriving()).toBeTruthy();
  });
});
