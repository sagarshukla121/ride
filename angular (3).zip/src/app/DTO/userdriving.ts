import { Companies } from "./companies";

export class Userdriving {
    userId !: number;
    username !: string;
    officialEmail !: string;
    phoneNumber !: string;
    designation !: string;
    role !: string;
    employeeId !: string;
    aadharNumber !: string;
    applicationstatus !: string;
    Id !: number;
    licenseNo !: string;
    expirationDate !: Date;
    rta !: string;
    allowedVehicles !: string;
    company !:Companies;
    userNme!:string;



}
