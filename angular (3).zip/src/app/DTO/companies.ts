export class Companies {
    
     id !: number;
    companyName !:string;
    buildingName !:string;
    securityInchargeName!: string;
    securityHelpDeskNumber!: string;
}
